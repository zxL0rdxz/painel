# [PAINEL-DE-CONSULTA 3.8(BETA)] &middot; [!["GitHub Discussions"](https://img.shields.io/badge/%20GitHub-%20Discussions-gray.svg?longCache=true&logo=github&colorB=purple)](https://github.com/Kiny-Kiny/Kiny-Painel/discussions)

<p align="center">
<img src="https://github.com/Kiny-Kiny/Kiny-Painel/blob/main/images%20(41).jpeg">
</p>

<p align="center">
<img alt="GitHub top language" src="https://img.shields.io/github/languages/top/Kiny-Kiny/Kiny-Painel?style=flat" /> 
<img alt="GitHub forks" src="https://img.shields.io/github/forks/Kiny-Kiny/Kiny-Painel?style=flat" />
<img alt="GitHub Repo stars" src="https://img.shields.io/github/stars/Kiny-Kiny/Kiny-Painel" />
<img alt="GitHub closed issues" src="https://img.shields.io/github/issues-closed/Kiny-Kiny/Kiny-Painel" />
<img alt="GitHub closed pull requests" src="https://img.shields.io/github/issues-pr-closed/Kiny-Kiny/Kiny-Painel" />
<img alt="GitHub commit activity" src="https://img.shields.io/github/commit-activity/m/Kiny-Kiny/Kiny-Painel" />
</p>

<p align="center">
<img src="https://github.com/Kiny-Kiny/Kiny-Painel/blob/main/IMG-20210313-WA0017.jpg">
</p>

<p align="center">Confira meu canal do YouTube. <a href="https://youtube.com/channel/UC1aTvkvmTVO7OJ6oixtJo8w"> Clique aqui!</a>

# Nota: Próxima Atualização será a última com coisas novas, o resto será para melhorar o script.

# Créditos 
> P0isonBR(Consulta de CPF/Atualização Automática)

> Snuking(Algumas ajudas no próprio script)

# Chave Pix para contribuir no desenvolvimento do Kiny-Painel:
 228463d7-0bec-44bd-bddd-a780d9530f27

# Patrocinadores

> Syne

> Douglas/Josuke

> Margarina

# INSTALAÇÃO 

> apt update && apt upgrade -y

> apt install git python

> apt install python2

> apt install python3

> git clone https://github.com/Kiny-Kiny/Kiny-Painel

> cd Kiny-Painel

> python3 main.py

# LOGIN

> Username: (Qualquer um)

> Password: VirtualInsanity

# CHANGELOG

- Bug corrigido no Updater

- Bug corrigido em consulta de placas

- Consulta Completa Por Número 

- Consulta Por Nome de Mãe 

- Consulta por Nome

# PRÉVIA

- Consulta de Nome

- Consulta CADSUS

- Consulta Score

- Consulta CPF(mais Info)

- Consulta de CNPJ(mais Info)

# Dúvidas? Me chame no Whatsapp: +55 (21) 7918-0533
